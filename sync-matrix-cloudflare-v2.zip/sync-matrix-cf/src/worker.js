// Cloudflare Worker entrypoint
// Routes:
//   /api/login       -> authenticate, returns session token
//   /api/logout      -> invalidate session
//   /api/me          -> who am I (validates session)
//   /api/users/*     -> admin-only user management
//   /api/schedule    -> shared schedule (GET/PUT)
//   /api/audit       -> audit log (GET)
//   /api/ws          -> WebSocket for live updates + audit stream
//   everything else  -> static assets

export { ScheduleRoom } from './schedule-room.js';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname.startsWith('/api/')) {
      const id = env.SCHEDULE.idFromName('main');
      const stub = env.SCHEDULE.get(id);
      return stub.fetch(request);
    }

    return env.ASSETS.fetch(request);
  },
};
