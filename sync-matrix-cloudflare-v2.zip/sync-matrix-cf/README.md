# Staff Sync Matrix — Cloudflare edition (v2)

A shared, live, multi-user staff scheduling tool with per-user accounts and full audit logging.

## What's new in v2

- **Per-user accounts** (username + password + display name)
- **Two roles**: admin (manages users) and editor (can use the schedule)
- **Audit log**: every structural change and shift edit is recorded with who, what, and when
- **Admin panel**: add/remove users and reset passwords from the UI
- **Session-based auth**: secure 30-day login tokens (no password stored in browser)
- **Passwords hashed** with PBKDF2 (100k iterations, SHA-256, random salt per user)

## Architecture

- **Worker** (`src/worker.js`) — routes all `/api/*` traffic to the Durable Object, serves static assets otherwise
- **Durable Object** (`src/schedule-room.js`) — single source of truth holding users, schedule, audit log, and sessions in persistent SQLite storage; broadcasts updates via WebSocket
- **Static frontend** (`public/index.html`) — single-file HTML app with login, schedule matrix, and audit panel

## Deployment

### Prerequisites

1. Cloudflare account (free): https://dash.cloudflare.com/sign-up
2. Node.js 18+: https://nodejs.org
3. A terminal

### Five commands

```bash
cd sync-matrix-cf
npm install
npx wrangler login
npm run deploy
```

On first deploy, Wrangler:
- Creates the Worker
- Creates the Durable Object + SQLite storage
- Uploads the frontend
- Returns a URL like `https://sync-matrix.<your-subdomain>.workers.dev`

**Open that URL immediately and:**

1. Log in with the default credentials: `admin` / `admin`
2. Click **Users** (top right)
3. **Change the admin password immediately** (click the Password button next to the admin user)
4. Create accounts for everyone on your team (each with their own username + display name)

### Custom domain (optional)

In the Cloudflare dashboard:
1. **Workers & Pages** → click **sync-matrix** → **Settings** → **Domains & Routes**
2. **Add** → **Custom domain**
3. Enter e.g. `schedule.yourcompany.com`
4. Done — Cloudflare handles DNS and SSL.

(Requires the domain to be on Cloudflare, which is free.)

## Roles

| Role | Can do |
|---|---|
| **Editor** | View and edit the schedule; view the audit log |
| **Admin** | Everything editors can, plus add/remove users and change roles/passwords |

You can promote/demote users at any time from the Users panel. The system prevents you from removing the last admin or deleting your own account.

## What gets logged

Every change to the schedule is recorded with:

- **Who** (display name + username)
- **When** (timestamp, shown relatively — "5m ago", "2h ago", etc.)
- **What** (action + human-readable summary)

Logged actions include:

- `category.create` / `rename` / `delete` / `update` (color change)
- `employee.create` / `delete`
- `shift.create` / `update` (move, resize, edit note) / `delete`
- `schedule.reset`
- `user.create` / `update` / `delete` (admin panel actions)

The log holds the most recent 2,000 entries (older entries roll off). Click **Export** in the audit panel to download the full log as CSV for archival.

What's NOT logged: collapse/expand category, view zoom changes, search/filter typing. These are UI-local and don't represent meaningful schedule changes.

## Local development

```bash
npm run dev
```

Starts at `http://localhost:8787` with hot reload.

Data in local dev is stored separately from production (in `.wrangler/`), so you can experiment safely.

## Costs

Cloudflare Workers free plan includes:
- 100,000 requests/day
- 1 million Durable Object reads/month
- 1 GB DO storage
- Unlimited WebSocket messages (within request budget)

A small team using this daily will stay well under the free tier. If you exceed it, the paid plan is $5/month.

## Security notes

- Passwords are hashed server-side with PBKDF2-SHA256 (100,000 iterations) and never stored or transmitted in plaintext after login
- Session tokens are random UUIDs, stored in browser localStorage, sent via the `Authorization: Bearer` header, and validated on every request
- Sessions expire after 30 days
- The default `admin/admin` credentials exist only for the very first login — **you must change the password immediately**. Anyone who finds your deployment URL before you change it can lock you out.
- There is no rate limiting on login attempts; for public deployments consider putting Cloudflare Access in front of this app as an additional layer.

## Troubleshooting

**Locked out of admin:** If you forgot the admin password and have no other admin, you can reset by running `npx wrangler d1 execute` against the Durable Object storage, or by deleting the users key via a one-off script. The simplest recovery is to use the Wrangler dashboard to clear the `users` key in DO storage, which re-seeds the default admin on next request.

**Durable Object class not found:** Re-run `npm run deploy`. The first deploy registers the class.

**WebSocket keeps disconnecting:** Check browser console. Usually means the token expired or was invalidated. Sign out and sign back in.

**Lost all schedule data:** DO storage is durable by design, but for safety click **Export JSON** regularly. You can always restore by pasting back via DevTools if needed.

## Files

```
sync-matrix-cf/
├── wrangler.toml          Cloudflare config
├── package.json           Scripts + wrangler dep
├── src/
│   ├── worker.js          HTTP entrypoint
│   └── schedule-room.js   Durable Object: users, schedule, audit, live sync
└── public/
    └── index.html         Frontend (login + matrix + audit)
```
